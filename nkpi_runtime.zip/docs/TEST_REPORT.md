> **9.1.4 update:** This page records retained source-processing rules and historical
> tests through 9.1.3. Presentation rules describing gray holes, a wedge cutaway or the
> prior renderer are superseded by **CONTINUOUS_REVIEW.md**. Source arrays and numerical
> estimates remain separate from the continuous display envelope. For tests performed
> for the current release, use **V914_VERIFICATION.md**, not earlier pass counts.

# Verification report — 9.1.3-map-support

## Release scope

This release corrects map support and presentation. The report reader, its calibration and 41/61/121-sample grids, original front/back coordinates, quantitative source fields, source minima, native import contract, Python calculations, trained artifacts, and dependency declarations are retained. Report surface topology adds a triangle only when its three original corners exist inside one original grid cell. Display normals may change beside an added triangle.

Map view is now a 2D XY projection using the selected report map's full physical circle. A missing anterior height no longer suppresses an independently accepted thickness or curvature map sample in that mode. Surface views still require supported patient-derived geometry.

These are software and report-color reproduction checks. They do not establish device-level measurement accuracy, clinical validation, or recovery of an unseen extremum. The earlier original March reports used for QA are different from the user's latest photographed case. The screenshots identify display symptoms, but do not provide the original report pixels needed to verify that exact case.

## Focused source checks

| Check | Outcome |
| --- | --- |
| Existing integrated coverage checks | 13 passed; two intentionally updated expectations allow bounded interior stripe repair while preserving actual missing rims |
| Independent map-support checks | 14 passed |
| New surface-support checks | 7 synthetic groups passed |
| Original March topology regression | 2 eyes passed; original coordinates, readings, null masks, coverage, field summaries and minima unchanged |
| Existing integrated-model checks | 12 passed |
| Existing measurement checks | 12 passed |
| Detailed report sampling | 3 passed |
| Full report display | 6 passed |
| Integrated report reader | 7 passed |

The new tests cover every four-corner presence pattern, no multi-cell bridging, no new vertices, native topology preservation, canonical uncertainty preview units, full map support across height holes and beyond smaller reconstruction apertures, maps without any usable patient geometry, all-uncertain preview fields, physical circle boundaries, narrow horizontal and diagonal stripes, rejection of broad disks and wide stripes, no uncertainty/recovered/estimated donors, native missing-data preservation, local residual rejection, original-array immutability, and connected affine holdouts.

The original March report topology changed from 3,910 to 3,938 triangles for OD and from 1,032 to 1,055 for OS. These 28 and 23 added triangles use existing source corners. The thickness minima and their original selected coordinates remain identical.

## Browser acceptance

| Rendering path | Outcome |
| --- | --- |
| WebGL-capable browser | 23 acceptance groups passed |
| Canvas fallback | 23 acceptance groups passed |

Both paths produced zero page errors and zero remote requests in the local harness. Full Map view uses the same Canvas raster in both paths; the tests also cover the respective 3D surface renderers.

Checks cover empty and partial states, all five quantitative fields, original minimum selection, manual selection and visit restoration, stable compatible color scales, unlit quantitative colors, contours, the full report-map circle independently of missing heights, absent-height report maps, explicit map selection and no-height disclosure, narrow-stripe provenance, uncertain colors without exact readouts, estimate toggles, unchanged original source objects, desktop/mobile layout, and bilateral PNG content.

Desktop, stacked phone layouts down to 320 CSS pixels, real report maps, synthetic missing-height maps, and uncertainty rendering were visually inspected. The synthetic fixtures are engineering tests; there is no example-patient option in the app.

## Connected report-color holdouts

The test removed connected blocks of previously accepted original report-color samples, then used the production display estimator. It assessed 285 blocks containing 3,941 hidden samples. The estimator filled 1,219 and abstained on the remainder. Error statistics below include only filled samples.

| Field | Filled / hidden | Mean absolute error | Maximum absolute error |
| --- | ---: | ---: | ---: |
| Thickness | 346 / 840 | 3.204 µm | 11.451 µm |
| Anterior curvature | 534 / 840 | 0.1896 D | 1.1810 D |
| Posterior curvature | 249 / 840 | 0.04445 D | 0.18651 D |
| Anterior elevation | 72 / 777 | 1.468 µm | 3.578 µm |
| Posterior elevation | 18 / 644 | 0.942 µm | 2.415 µm |

These compare estimates with held-out **report-color estimates**, not native instrument measurements. They are not clinical accuracy bounds. The engineering thresholds are documented in `SURFACE_DATA.md`; unusual pathology, broad missing regions and unseen extrema remain limitations. The estimator abstains where the local requirements fail.

## Available source information recovered for display

On the earlier March reports:

| Accepted thickness samples | OD | OS |
| --- | ---: | ---: |
| v9.1.2 retained surface | 7,289 | 2,069 |
| v9.1.3 retained surface | 7,315 | 2,090 |
| v9.1.3 full report Map view | 9,900 | 7,687 |
| Additional full-map display estimates | 10 | 14 |

The main gain comes from displaying already accepted information independently of the height mesh. The OS map is also wider than its accepted reconstruction aperture; these counts must not all be described as internal-hole recovery. Coverage denominators differ between Map view and surface view. No additional source measurements are created.

Gray remains genuinely unavailable color support. Stripes identify added estimates. Crosshatching identifies ambiguous or endpoint-overlapping color previews; exact values remain withheld. An endpoint-overlapping interval does not prove the device measurement exceeded the printed scale.

## Packaged application and release integrity

The five-file candidate passed a clean extracted-launcher run from a different working directory, baseline and longitudinal OD/OS calculation and PDF events, all four complete eye-result comparisons against v9.1.2, and all 10 actual packaged Streamlit browser groups. The latter include a pointer click on an accepted map sample outside the reconstructed aperture without assigning it a surface height, then restoration of the original selected minimum.

The candidate contains 132 runtime files, including the 131-entry source manifest, and resolves all 41 local HTML asset references. Critical renderer, model, coverage, measurement and stylesheet bytes served by Streamlit match the packaged candidate. The actual app was checked at desktop and 320-pixel phone widths without horizontal overflow. Original reader and OCR runtime assets are unchanged; no new full OCR run was needed for this display-only correction.

The delivered archive is rebuilt after updating this verification document. A final integrity check must verify both ZIP CRCs, all manifest hashes, exactly five upload files below 25 MiB each, the launcher's runtime checksum, and application-code identity with the tested candidate. Only this document and the generated manifest may differ from that candidate.

The upload contract remains five files: `kcn_dual_calculator_app.py`, intact `nkpi_runtime.zip`, `requirements.txt`, `README.md`, and `.streamlit/config.toml`. Python 3.12 is the tested runtime. Browser OCR assets remain bundled; this release changes no dependency versions and makes no claim that every dependency is the latest available release.

Patient images, patient-derived grids, photographs, QA screenshots and holdout data are excluded from the upload package. Only synthetic fixtures are included in the source tests.

## Remaining limits

- Large missing surface regions are still unavailable in 3D. The 2D map does not supply their height.
- Fine spatial sampling cannot recover information absent from the original report colors or hidden behind print annotations.
- A color preview can remain visually continuous while its numeric value is uncertain; it must not be treated as a measured point.
- Native missing numerical values are not repaired. The unchanged native adapter still derives viewer samples from its retained vertices; native measurements discarded by an upstream missing-height mask are not recovered by this patch.
- The original reconstructed minimum can differ from a fine report-color minimum or the device's printed scalar. Display estimates do not change the original source minimum.
- A real numerical export from the clinic remains necessary to validate a device-specific import adapter and compare directly against its spatial measurements.
