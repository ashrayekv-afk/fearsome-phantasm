# 9.1.4 verification record

Test scope: local source code, offline browser rendering/interaction and release packaging.
This is an engineering check, not anatomical/clinical validation.

## Checks performed for this release

- 21 JavaScript source regression scripts completed successfully. The new
  `tests/test_continuous_review.cjs` contributes 13 assertions covering C provenance,
  eye/visit isolation, immutability, closed-mesh topology, gap readouts and unchanged
  source coordinates/minima. Existing scripts cover retained source/import/geometry logic.
- 41 Python tests passed from `test_model_interval.py`, `test_baseline_outlook.py`, and
  `test_evidence.py`. Python source compilation also passed.
- 12 paired synthetic calculator payloads (24 eye results), spanning baseline and
  longitudinal modes, ages 18/35/65, and different C values, produced identical full
  calculator responses to 9.1.3 after excluding only the UI-version string.
- All three frozen model/registry JSON files and all Python calculation modules except
  the service UI-version string are byte-identical to 9.1.3.
- 25 browser checks passed in Chromium/Playwright using the real distributed viewer
  JavaScript and styles, in an inline offline test harness. They tested independent C
  labels, default-point logic, field/visit changes, visual completion without invented
  readings, profiles, linked slice direction, support, contour control, equal-scale
  profile camera, PNG export, source modal, and phone overflow. No JavaScript errors
  occurred. This is a Canvas renderer; no WebGL test is claimed for the new renderer.
- A prepared, decoded earlier uploaded bilateral report example loaded into both views.
  Source-report image access and mobile layout were visually inspected. This fixture
  was not a fresh automatic OCR run, is not the patient in the latest photographs,
  and is NOT included in the distributed package.
- A purely synthetic numerical test input tested native schema paths and unsupported
  patches. It is not evidence that a clinic-specific numerical Pentacam export adapter
  has been validated. No clinical demo-eye data are shipped in the application.
- Closed-shell check: every edge of the complete front/back/rim mesh occurs twice,
  with finite vertices. This checks topological continuity, NOT anatomical truth,
  freedom from all possible self-intersections, or reconstruction accuracy.
- Original-versus-completed fields were checked for unchanged finite anchors and
  original minima. Changing the scalar C did not change surface geometry.
- Final outer and inner ZIP CRCs, runtime hash, complete runtime manifest and script
  syntax were checked. The five-file outer package was extracted into a clean directory;
  its launcher successfully verified/installed the matching inner runtime and reused
  it. A deliberately wrong expected hash was rejected. No stale source folder is needed.

## Not retested / not established

Streamlit was not installed in this execution environment, and installation from the
package repository failed because network/DNS access was unavailable. Accordingly,
this release was NOT freshly started in a running Streamlit server or the user's cloud
deployment. Python 3.12 remains the intended deployment runtime with the retained
requirements, but the local Python tests used Python 3.13.5. The first cloud deployment
and first fresh report import should be checked against the source exam.

No fresh end-to-end PDF/JPG OCR, live clinic hosting, cloud browser, new PDF report
export, institutional security approval, or clinical accuracy assessment was performed.
The retained report generator and OCR source/assets were not changed. Numerical
reconstruction error against native Pentacam coordinates was not assessed. The C/model
mismatch is exposed rather than silently corrected, and a large discrepancy requires
checking the original examination, eye/visit association and extraction quality.

The backend's previous validation status and limitations remain unchanged; this release
does not clinically validate NKPI or its existing interval-coefficient amendment.
