'use strict';
const assert=require('node:assert/strict');
const R=require('../components/cornea/continuous_review.js'),I=require('../components/cornea/integrated_model.js'),M=require('../components/cornea/integrated_measurements.js');
let n=0;function test(label,fn){fn();n++;console.log('PASS '+label);}
function fixture(eye='OD',visit='first'){
 const n=31,a=Array.from({length:n},(_,i)=>-4.5+i*.3),g=fn=>a.map(y=>a.map(x=>Math.hypot(x,y)>4.5?null:fn(x,y)));
 return {eye,visit,pages:[],surface:{schema:'nkpi-corneal-surface-1',kind:'measured',source:'device_numeric_export',eye,visit,units:{xy:'mm',z:'mm',elevation:'um',thickness:'um',curvature:'D'},coordinate_system:{origin:'corneal_vertex',x_positive:eye==='OD'?'nasal':'temporal',y_positive:'superior',z_positive:'anterior'},x_mm:a,y_mm:a,
 anterior:{z_mm:g((x,y)=>Math.abs(x)<.5&&Math.abs(y)<.5?null:Math.sqrt(7.8**2-x*x-y*y)-7.8+.08*Math.exp(-(x*x+(y+.8)**2))),curvature_D:g((x,y)=>Math.abs(x)<.5&&Math.abs(y)<.5?null:44+8*Math.exp(-(x*x+(y+.8)**2))),curvature_type:'axial',elevation_um:g((x,y)=>80*Math.exp(-(x*x+(y+.8)**2))),elevation_reference:{type:'best_fit_sphere',fit_diameter_mm:8}},posterior:{z_mm:g((x,y)=>Math.sqrt(7.8**2-x*x-y*y)-7.8-.5),curvature_D:g(()=>-7.8),curvature_type:'axial'},thickness_um:g((x,y)=>Math.abs(x)<.5&&Math.abs(y)<.5?null:470+7*(x*x+(y+.7)**2)),thickness_definition:'device_pachymetry'}};
}
const result={case:{eye:'OD',mode:'baseline',verified:true,first:{C:430},latest:null}};
let f=fixture(),s=I.fromReport(f),before=JSON.stringify(s),d=R.build(s,f,result);
test('C comes from the verified calculator case, not the reconstructed minimum',()=>{assert.equal(d.verifiedC.value,430);assert(d.minimum.thickness>430);assert.equal(d.delta,d.minimum.thickness-430);});
test('No location is invented from C alone',()=>{assert.equal(d.selection.source,'reconstruction');assert.equal(d.selection.x,d.minimum.x);});
test('Display completion leaves every original source field and coordinate unchanged',()=>assert.equal(JSON.stringify(s),before));
test('Completion cannot change the original minimum',()=>assert.deepEqual(M.findThinnest(s),d.minimum));
test('No numeric source value appears in a broad central gap',()=>assert.equal(d.reading('thickness',0,0).value,null));
test('Display-only surface is finite in the gap',()=>assert(d.front(0,0).every(Number.isFinite)));
test('Closed front/back mesh has no boundary holes',()=>{const m=R.mesh(d),edges=new Map();for(const ids of m.closed)for(const [a,b]of [[ids[0],ids[1]],[ids[1],ids[2]],[ids[2],ids[0]]]){const key=[a,b].sort((x,y)=>x-y).join(',');edges.set(key,(edges.get(key)||0)+1);}assert([...edges.values()].every(x=>x===2));assert(m.points.concat(m.back).flat().every(Number.isFinite));});
test('Readable native height anchors retain supplied coordinates',()=>{const v=s.vertices.find(v=>v?.front&&Math.hypot(v.front[0],v.front[1])<3);assert(Math.abs(d.front(v.front[0],v.front[1])[2]-v.front[2])<1e-10);});
test('Verified coordinates are used only for a correctly linked single scan',()=>{const r=structuredClone(result);r.case.landmarks={thin_x:.4,thin_y:-.6};const a=R.build(s,f,r);assert.equal(a.selection.source,'reported');assert.equal(a.selection.x,.4);assert.equal(a.selection.y,-.6);});
test('Unscoped longitudinal coordinates do not leak to later visits',()=>{const r={case:{eye:'OD',mode:'longitudinal',verified:true,first:{C:430},latest:{C:410},landmarks:{thin_x:.4,thin_y:-.6}}};assert.equal(R.cFor(r,'OD','latest').value,410);assert.equal(R.cFor(r,'OD','first').value,430);assert.equal(R.landmarkFor({...f,visit:'latest'},r,4.5),null);});
test('No fallback C from the other eye, another visit, or unverified inputs',()=>{assert.equal(R.cFor(result,'OS','first'),null);assert.equal(R.cFor(result,'OD','latest'),null);assert.equal(R.cFor({case:{...result.case,verified:false}},'OD','first'),null);});
test('Harmonic fill never changes anchors or creates an extremum outside their range',()=>{const input=[0,null,2,null,null,null,0,null,2],copy=[...input],out=R.complete(input,3,3);assert.deepEqual(input,copy);assert.equal(out.values[0],0);assert.equal(out.values[2],2);assert([...out.values].every(v=>v>=0&&v<=2));});
test('Changing C does not deform the displayed cornea',()=>{const e=R.build(s,f,{case:{...result.case,first:{C:390}}});assert.deepEqual(e.front(.3,-.6),d.front(.3,-.6));assert.deepEqual(e.back(.3,-.6),d.back(.3,-.6));});
console.log(`${n} continuous review checks passed`);
if(process.env.WRITE_FIXTURE){require('fs').writeFileSync(process.env.WRITE_FIXTURE,JSON.stringify({sets:{OD:[fixture('OD','first')],OS:[fixture('OS','first')]},results:{OD:result,OS:{case:{eye:'OS',mode:'baseline',verified:true,first:{C:455},landmarks:{thin_x:.3,thin_y:-.6}}}}}));}
