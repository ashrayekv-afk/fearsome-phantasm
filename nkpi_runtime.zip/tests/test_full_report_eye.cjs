'use strict';
// Engineering fixtures only. These checks establish the display/data contract,
// not clinical accuracy of a reconstructed patient surface.
const assert=require('node:assert/strict');
const Shape=require('../components/cornea/patient_shape.js');
const I=require('../components/image_regions.js');
let count=0;
const test=(name,fn)=>{fn();count++;console.log('PASS '+name);};
const near=(a,b)=>assert.ok(Number.isFinite(a)&&Math.abs(a-b)<1e-8,`${a} != ${b}`);
function cells(n,diameter,extent,fn){const c=(n-1)/2,step=diameter*extent/(n-1);return Array.from({length:n},(_,j)=>Array.from({length:n},(_,i)=>{if(Math.hypot(i-c,j-c)>c+1e-8)return null;const value=fn((i-c)*step,(c-j)*step);return value===null?null:{value,lo:value-1,hi:value+1};}));}
function full(diameter,key,fn){const grid=cells(61,diameter,1,fn),inside=grid.flat().filter((_,k)=>Math.hypot(k%61-30,Math.floor(k/61)-30)<=30+1e-8).length;return {schema:'nkpi-report-display-grid-1',extent:1,diameter_mm:diameter,[key]:grid,coverage:grid.flat().filter(Boolean).length/inside};}
function fixture(){
 const d=9,e=(x,y)=>20+3*x+2*y,t=(x,y)=>500+10*x+5*y;
 const shape={schema:'nkpi-image-shape-1',source:'report_elevation_estimate',reference:'centered_untilted_float_bfs',bfs_radius_mm:7.8,fit_diameter_mm:8,diameter_mm:d,extent:2/3,elevation_um:cells(41,d,2/3,e),legend_step_um:2,full_display:full(d,'elevation_um',e)};
 const map=(id,fn)=>({schema:'nkpi-report-image-map-1',id,unit:id==='thickness'?'µm':'D',map_type:id==='thickness'?'pachymetry':'axial',source:'report_color_estimate',diameter_mm:d,registration:'printed_plot_circle',extent:2/3,grid:cells(41,d,2/3,fn),full_display:full(d,'grid',fn)});
 return {shape,thickness:map('thickness',t),curvature:map('anterior',(x,y)=>45+x+.5*y)};
}

test('A full 9-mm printed field retains its physical 9-mm diameter and original grid resolution',()=>{
 const f=fixture(),before=JSON.stringify(f),m=Shape.addImageOverlays(Shape.imageModel(f.shape,f.thickness),[f.curvature]);
 assert.equal(m.nx,61);assert.equal(m.ny,61);near(m.radius,4.5);assert.equal(m.fullDisplayUsed,true);
 const v=m.vertices[30*61+55];near(v.front[0],3.75);near(v.front[1],0);near(v.front[2],Math.sqrt(7.8**2-3.75**2)-7.8+(20+3*3.75)/1000);near(v.thickness,537.5);near(v.anterior,48.75);
 assert.equal(JSON.stringify(f),before);
});
test('Legacy central data remains a 6-mm field and is never enlarged to match the full iris',()=>{
 const f=fixture();for(const item of Object.values(f))delete item.full_display;
 const m=Shape.addImageOverlays(Shape.imageModel(f.shape,f.thickness),[f.curvature]);assert.equal(m.nx,41);near(m.radius,3);assert.equal(m.fullDisplayUsed,false);
 const p=Shape.anatomicalMesh(m).sample(3.75,0);assert.equal(p.sourceId,-1);assert.equal(p.anterior,null);assert.equal(p.displayValues.anterior,null);
});
test('Sparse full elevation falls back to valid central geometry without fabricating periphery',()=>{
 const f=fixture();f.shape.full_display=full(9,'elevation_um',(x,y)=>Math.hypot(x,y)<1?30:null);
 const m=Shape.imageModel(f.shape,f.thickness);assert.equal(m.nx,41);near(m.radius,3);assert.equal(m.kind,'estimated');assert.equal(m.fullDisplayUsed,false);assert.match(m.fullDisplayIssue,/coverage/);
 const center=m.vertices[20*41+20];near(center.elevation,20);near(center.thickness,500);
});
test('A full map without front heights keeps a reference shape and true wider map locations',()=>{
 const f=fixture(),before=JSON.stringify(f.curvature),m=Shape.referenceModel([f.curvature]);
 assert.equal(m.kind,'reference');assert.equal(m.nx,61);near(m.radius,4.5);near(m.vertices[30*61+55].anterior,48.75);assert.equal(m.vertices[30*61+55].thickness,null);assert.equal(JSON.stringify(f.curvature),before);
});
test('Missing peripheral pachymetry does not erase usable full-field front elevation',()=>{
 const f=fixture();delete f.thickness.full_display;const m=Shape.imageModel(f.shape,f.thickness),v=m.vertices[30*61+55];
 assert.ok(v);near(v.front[0],3.75);assert.equal(v.thickness,null);assert.equal(v.back,null);near(m.radius,4.5);
});
test('Posterior elevation uses its own signed field and never replaces back geometry',()=>{
 const f=fixture(),without=Shape.imageModel(f.shape,f.thickness),p=(x,y)=>-15+4*x-y;
 f.shape.posterior_elevation={schema:'nkpi-image-elevation-map-1',surface:'posterior',source:'report_elevation_estimate',reference:'independent_posterior_float_bfs',unit:'um',bfs_radius_mm:6.5,fit_diameter_mm:8,diameter_mm:9,extent:2/3,elevation_um:cells(41,9,2/3,p),full_display:full(9,'elevation_um',p),legend_step_um:2};
 const m=Shape.imageModel(f.shape,f.thickness);assert.ok(m.overlays.some(l=>l.id==='posterior_elevation'));near(m.vertices[30*61+55].posterior_elevation,0);near(m.vertices[30*61+30].posterior_elevation,-15);
 assert.deepEqual(m.vertices.map(v=>v&&[v.front,v.back,v.thickness]),without.vertices.map(v=>v&&[v.front,v.back,v.thickness]));
 assert.equal(m.mapDefinitions.posterior_elevation.reference,'independent_posterior_float_bfs');
});
test('Invalid full-grid metadata cannot silently alter physical size or source values',()=>{
 for(const mutate of [f=>f.shape.full_display.diameter_mm=12,f=>f.shape.full_display.extent=2/3,f=>f.curvature.full_display.grid[0][0]={value:50,lo:49,hi:51},f=>f.shape.full_display.coverage=.1]){
  const f=fixture();mutate(f);assert.throws(()=>{I.validateShape(f.shape);I.validateMap(f.curvature);});
 }
});
console.log(`${count} full-report eye display checks passed.`);
