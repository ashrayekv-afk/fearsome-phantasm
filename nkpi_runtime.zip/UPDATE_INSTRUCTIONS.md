# Install 9.1.4-continuous-c-audit

Extract NKPI_v914_GitHub_Upload.zip once. Replace the launcher, nkpi_runtime.zip,
requirements.txt and README.md at repository root, and .streamlit/config.toml in its
folder. Leave nkpi_runtime.zip zipped. Upload launcher and archive together.

Keep kcn_dual_calculator_app.py as the main file and Python 3.12 as the intended
Streamlit deployment runtime. Reboot, refresh and confirm 9.1.4-continuous-c-audit.
Reimport the original reports, verify eye/visit/C and other inputs, then calculate.

Open the bilateral corneal review. Verified C is shown separately from the reconstructed
minimum; their difference is not eliminated by changing the source inputs. Without
verified XY coordinates the marker is an explicitly reconstructed location.

Whole surface keeps the reference natural eye; Map review shows a completed map field;
Slice through point shows a line and profile without cutting away tissue. Show data
support reveals completion. Large completed areas do not receive numerical readouts.

This is a display update, not a newly validated clinical model. See README.md and
V914_VERIFICATION.md for testing scope and accuracy limitations.
