"""NKPI bilateral research assessment."""
