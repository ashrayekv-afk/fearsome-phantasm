/* Measurement display helpers for source models, never anatomical display meshes.
 * Selection, color scales and contours do not change any source coordinate or
 * value. A mapped minimum is not a substitute for the device's whole-cornea C.
 */
(function(root){'use strict';
const FIELDS=Object.freeze(['thickness','anterior','posterior','elevation','posterior_elevation']);
const SIGNED=new Set(['elevation','posterior_elevation']);
const finite=Number.isFinite;
const identities=new WeakMap();let nextIdentity=0;
const CURVATURE=Object.freeze([
 Object.freeze([.10,.28,.55]),Object.freeze([.12,.60,.69]),Object.freeze([.94,.91,.65]),
 Object.freeze([.95,.56,.23]),Object.freeze([.70,.17,.15])
]);
const ELEVATION=Object.freeze([
 Object.freeze([.12,.32,.62]),Object.freeze([.48,.72,.84]),Object.freeze([.96,.95,.91]),
 Object.freeze([.93,.65,.36]),Object.freeze([.70,.27,.12])
]);

function sourceVertex(v){
 return !!v&&v.front?.length===3&&[0,1,2].every(i=>finite(v.front[i]))&&
  v.provenance!=='filled'&&v.provenance!=='reference'&&v.supported!==false;
}
function fieldValue(vertex,field){
 const value=vertex?.[field];
 if(!FIELDS.includes(field)||!finite(value)||(field==='thickness'&&value<=0))return null;
 return field==='posterior'?Math.abs(value):value;
}
function findThinnest(model){
 let best=null;
 for(const [index,v]of (model?.vertices||[]).entries()){
  if(!sourceVertex(v))continue;
  const thickness=fieldValue(v,'thickness');if(thickness===null)continue;
  const [x,y]=v.front,distance=x*x+y*y;
  if(best&&(thickness>best.thickness||
    (thickness===best.thickness&&(distance>best.distance||
      (distance===best.distance&&index>best.index)))))continue;
  best={index,thickness,x,y,distance};
 }
 if(!best)return null;
 delete best.distance;
 return {...best,scope:'available-mapped-samples',label:'Lowest mapped pachymetry',
  approximate:model.sourceKind==='report-image'||model.mapSource==='image'||model.kind==='estimated',
  geometryAvailable:model.hasPatientGeometry!==false&&model.kind!=='reference'};
}
function getFieldRange(model,field){
 if(!FIELDS.includes(field))return null;
 let min=Infinity,max=-Infinity,count=0;
 for(const vertex of model?.vertices||[]){
  if(!sourceVertex(vertex))continue;
  const value=fieldValue(vertex,field);if(value===null)continue;
  min=Math.min(min,value);max=Math.max(max,value);count++;
 }
 return count?{min,max,count}:null;
}
function canonical(value){
 if(Array.isArray(value))return value.map(canonical);
 if(value&&typeof value==='object'){
  const out={};
  for(const key of Object.keys(value).sort())if(key!=='partial'&&key!=='coverage'&&value[key]!==undefined)out[key]=canonical(value[key]);
  return out;
 }
 return value;
}
function rangeSignature(model,field){
 if(!model||!FIELDS.includes(field))return null;
 let definition=model.mapDefinitions?.[field]||null;
 // Image anterior elevations use the adapter's explicitly assumed frame.
 // Fitting diameters remain part of the reference definition, not plot size.
 if(!definition&&field==='elevation'&&(model.kind==='estimated'||model.sourceKind==='report-image'))
  definition={type:'best_fit_sphere',reference:'centered_untilted_float_bfs',fit_diameter_mm:model.fit_diameter??null};
 const curvature=field==='anterior'||field==='posterior';
 const ambiguous=curvature&&(!definition?.type||
  (['device_reported','unspecified','unknown'].includes(definition.type)&&!definition.definition_id));
 let identity=null;
 if(ambiguous){if(!identities.has(model))identities.set(model,++nextIdentity);identity=identities.get(model);}
 return JSON.stringify(canonical({field,sourceKind:model.sourceKind||model.kind||'unknown',
  mapSource:model.mapSource||'unknown',definition,ambiguousSource:identity}));
}
function paletteStops(field){
 if(!FIELDS.includes(field))return [];
 const palette=SIGNED.has(field)?ELEVATION:CURVATURE;
 return (field==='thickness'?[...palette].reverse():palette).map(color=>[...color]);
}
function niceStep(target){
 if(!finite(target)||target<=0)return null;
 const power=Math.pow(10,Math.floor(Math.log10(target))),fraction=target/power;
 for(const factor of [1,1.5,2,2.5,4,5,7.5,10])if(fraction<=factor)return factor*power;
 return 10*power;
}
function makeScale(field,input){
 if(!FIELDS.includes(field)||!finite(input?.min)||!finite(input?.max)||input.max<input.min)return null;
 const dataMin=input.min,dataMax=input.max;
 if(!finite(dataMax-dataMin))return null;
 let min,max,step;
 if(SIGNED.has(field)){
  const extent=Math.max(Math.abs(dataMin),Math.abs(dataMax));
  step=niceStep((extent||10)/2);if(!step)return null;
  max=2*step;min=-max;
 }else if(dataMin===dataMax){
  const halfSpan=field==='thickness'?25:field==='posterior'?.2:1;
  step=niceStep(halfSpan/2);min=dataMin-2*step;max=dataMax+2*step;
  if(dataMin>=0&&min<0){min=0;max=4*step;}
 }else{
  step=niceStep((dataMax-dataMin)/4);if(!step)return null;
  min=Math.floor(dataMin/step)*step;max=min+4*step;
  // An outward lower rounding can consume part of one interval. Enlarge
  // the increment until five equally spaced ticks contain both endpoints.
  for(let attempt=0;max<dataMax&&attempt<12;attempt++){
   step=niceStep(step*(1+1e-10));min=Math.floor(dataMin/step)*step;max=min+4*step;
  }
 }
 if(!finite(min)||!finite(max)||!finite(step)||max<=min||min>dataMin||max<dataMax)return null;
 const ticks=Array.from({length:5},(_,i)=>min+i*step);ticks[4]=max;
 if(SIGNED.has(field))ticks[2]=0;
 return {min,max,dataMin,dataMax,step,ticks,stops:paletteStops(field)};
}
function normalize(field,value,bounds){
 if(!FIELDS.includes(field)||!finite(value)||!finite(bounds?.min)||!finite(bounds?.max)||bounds.max<=bounds.min||
  (field==='thickness'&&value<=0))return null;
 const numeric=field==='posterior'?Math.abs(value):value;
 return Math.max(0,Math.min(1,(numeric-bounds.min)/(bounds.max-bounds.min)));
}
function colorAt(field,value,bounds){
 const t=normalize(field,value,bounds);if(t===null)return null;
 const stops=paletteStops(field),position=t*4,index=Math.min(3,Math.floor(position)),fraction=position-index;
 return stops[index].map((channel,k)=>channel*(1-fraction)+stops[index+1][k]*fraction);
}
function contourLevels(scale){
 return Array.isArray(scale?.ticks)?scale.ticks.filter(value=>finite(value)&&value>scale.min&&value<scale.max):[];
}
function sharedScales(models){
 const unique=[...new Set((models||[]).filter(model=>model&&typeof model==='object'))];
 const result=new Map(unique.map(model=>[model,{}])),groups=new Map();
 for(const model of unique)for(const field of FIELDS){
  const range=getFieldRange(model,field);if(!range)continue;
  const signature=rangeSignature(model,field);
  let group=groups.get(signature);
  if(!group){group={field,min:range.min,max:range.max,models:[],count:0};groups.set(signature,group);}
  group.min=Math.min(group.min,range.min);group.max=Math.max(group.max,range.max);
  group.models.push(model);group.count+=range.count;
 }
 for(const [signature,group]of groups){
  const scale=makeScale(group.field,group);if(!scale)continue;
  const eyes=[...new Set(group.models.map(model=>model.eye).filter(Boolean))].sort();
  const visits=[...new Set(group.models.map(model=>model.visit).filter(Boolean))].sort();
  for(const model of group.models)result.get(model)[group.field]={...scale,
   ticks:[...scale.ticks],stops:scale.stops.map(color=>[...color]),signature,
   shared:group.models.length>1,sourceCount:group.models.length,count:group.count,
   eyes:[...eyes],visits:[...visits],sharedAcrossEyes:eyes.length>1,sharedAcrossVisits:visits.length>1};
 }
 return result;
}
const api={FIELDS,findThinnest,getFieldRange,rangeSignature,makeScale,paletteStops,colorAt,normalize,contourLevels,sharedScales};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.NKPIIntegratedMeasurements=api;
})(typeof window!=='undefined'?window:globalThis);
